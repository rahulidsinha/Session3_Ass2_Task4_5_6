

import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class Ass_3_2_Task4 {

	public static void main(String[] args) throws IOException {
		
		Configuration conf = new Configuration();
		
		// adding the core-site.xml and hdfs-site.xml in Configuration
		conf.addResource(new Path("/usr/local/hadoop/etc/hadoop/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/etc/hadoop/hdfs-site.xml"));
		
		FileSystem fs = FileSystem.get(conf);

		// Default start timestamp is zero, end timestamp is infinite
		long input_timestamp_start = 0;
		long input_timestamp_end = Long.MAX_VALUE;
		
		// First Argument = input path, Second Argument = Start_timestamp, Third Argument = End Timestamp 
		Path input_path = new Path(args[0]);
		input_timestamp_start = Long.parseLong(args[1]);
		input_timestamp_end = Long.parseLong(args[2]);
		
		
		Ass_3_2_Task4.displayFilesByTimeStamp(fs,input_path,input_timestamp_start,input_timestamp_end);
	}
	
	// Function to list files between start and end timestamp
	public static void displayFilesByTimeStamp(FileSystem fs,Path path, long input_timestamp_start, long input_timestamp_end) throws FileNotFoundException, IOException
	{
		FileStatus[] status = fs.listStatus(path);
		
		for(FileStatus file:status)
		{
			if (file.isFile())
			{
				// Get the file timestamp
				long file_timestamp = file.getModificationTime();
				
				// Check if the file timestamp is between timstamp_start and timestamp_end
				if((file_timestamp>input_timestamp_start) && (file_timestamp<input_timestamp_end))
				{
					System.out.println("Name       : "+file.getPath().toString());
					System.out.println("TimeStamp  : "+file.getModificationTime());
					System.out.println("Length     : "+file.getLen());
					System.out.println("Permission : "+file.getPermission().toString());
					System.out.println();
				}
			}
			
			// If it is a directory, traverse all the sub-directories and files
			if(file.isDirectory())
			{
				Path temp_path = file.getPath();
				displayFilesByTimeStamp(fs,temp_path, input_timestamp_start, input_timestamp_end);
			}
		}
	}
}


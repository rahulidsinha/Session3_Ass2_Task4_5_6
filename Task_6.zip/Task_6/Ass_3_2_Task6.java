import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class Ass_3_2_Task6 {

	public static void main(String[] args) throws IOException {
		Configuration conf = new Configuration();
		
		// adding the core-site.xml and hdfs-site.xml in Configuration
		conf.addResource(new Path("/usr/local/hadoop/etc/hadoop/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/etc/hadoop/hdfs-site.xml"));
		
		FileSystem fs = FileSystem.get(conf);
		
		// take Local src path and Hdfs output path from command line argument 
		Path input_local_path = new Path(args[0]);
		Path output_hdfs_path = new Path(args[1]);
		
		Ass_3_2_Task6.copyToHdfs(fs, input_local_path, output_hdfs_path);

	}
	
	public static void copyToHdfs(FileSystem fs, Path input_local_path, Path output_hdfs_path) throws IOException
	{
		// Copy the file from local file system to hdfs
		fs.copyFromLocalFile(input_local_path, output_hdfs_path);
	}

}

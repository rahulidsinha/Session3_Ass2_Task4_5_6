import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class Ass_3_2_Task5 {

	public static void main(String[] args) throws IOException {
		
		Configuration conf = new Configuration();
		
		// adding the core-site.xml and hdfs-site.xml in Configuration
		conf.addResource(new Path("/usr/local/hadoop/etc/hadoop/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/etc/hadoop/hdfs-site.xml"));
		
		// path to the file to be read
		Path input_path = new Path(args[0]);
		
		FileSystem fs = FileSystem.get(conf);
		
		Ass_3_2_Task5.readHdfsFile(fs, input_path);
		
		fs.close();

	}
	
	public static void readHdfsFile(FileSystem fs, Path input_path) throws IOException
	{
		// Check if the path exists or not
		if(!fs.exists(input_path))
		{
			System.out.println("Path does not exists");
			System.exit(-1);
		}
		
		// Check if the supplied path is for a file, not a directory
		if(fs.isDirectory(input_path))
		{
			System.out.println("Path has to be of a file, not directory !!");
			System.exit(-1);
		}
		
		FSDataInputStream in;
		
		in = fs.open(input_path);
		
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		
		// Read the first line of the hdfs file
		String line = br.readLine();
		
		// read until the end of file
		while(line != null)
		{
			System.out.println(line);
			line = br.readLine();
		}
		in.close();
	}

}
